//
//  startHealthMeasurementByApp.m
//  Ble SDK Demo
//
//  Created by yang sai on 2022/6/6.
//

#import "startHealthMeasurementByApp.h"

@interface startHealthMeasurementByApp ()<MyBleDelegate>
{
    
    __weak IBOutlet UISegmentedControl *segDataType;
   
    
    __weak IBOutlet UITextView *myTextView;
    __weak IBOutlet UIButton *btnStart;
    
    NSString * strText;
}
@end

@implementation startHealthMeasurementByApp

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [NewBle sharedManager].delegate = self;
    [self myMasory];
}

  
-(void)myMasory
{
    [segDataType setTitle:LocalForkey(@"HRV") forSegmentAtIndex:0];
    [segDataType setTitle:LocalForkey(@"心率") forSegmentAtIndex:1];
    [segDataType setTitle:LocalForkey(@"血氧") forSegmentAtIndex:2];
    [segDataType setTitle:LocalForkey(@"Temperature") forSegmentAtIndex:3];
    [btnStart setTitle:LocalForkey(@"开始") forState:UIControlStateNormal];
    
    [segDataType mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(self.view.mas_centerX);
        make.top.mas_equalTo(self.view.mas_top).offset(88*Proportion);
        make.width.mas_equalTo(343*Proportion);
        make.height.mas_equalTo(32);
    }];
    [segDataType mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(self.view.mas_centerX);
        make.top.mas_equalTo(self.view.mas_top).offset(88*Proportion);
        make.width.mas_equalTo(343*Proportion);
        make.height.mas_equalTo(32);
    }];
    

    [btnStart mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(self.view.mas_centerX);
        make.top.mas_equalTo(segDataType.mas_bottom).offset(10*Proportion);
        make.width.mas_equalTo(160*Proportion);
        make.height.mas_equalTo(50*Proportion);
    }];
    [myTextView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(self.view.mas_centerX);
        make.top.mas_equalTo(btnStart.mas_bottom).offset(10*Proportion);
        make.width.mas_equalTo(351*Proportion);
        make.height.mas_equalTo(Height -260*Proportion);
    }];
}

#pragma mark MyBleDelegate
-(void)ConnectSuccessfully
{
    
}
-(void)Disconnect:(NSError *_Nullable)error
{
    [PishumToast showToastWithMessage:LocalForkey(@"设备断开连接") Length:TOAST_SHORT ParentView:self.view];
}
-(void)scanWithPeripheral:(CBPeripheral*_Nonnull)peripheral advertisementData:(NSDictionary<NSString *, id> *_Nonnull)advertisementData RSSI:(NSNumber *_Nonnull)RSSI
{
    
}
-(void)ConnectFailedWithError:(nullable NSError *)error
{
    
}
-(void)EnableCommunicate
{
    
}

-(void)BleCommunicateWithPeripheral:(CBPeripheral*)Peripheral data:(NSData *)data
{
    DeviceData_J2208A * deviceData = [[DeviceData_J2208A alloc] init];
    deviceData  = [[BleSDK_J2208A sharedManager] DataParsingWithData:data];
    BOOL end = deviceData.dataEnd;
    if(deviceData.dataType == DeviceMeasurement_HR_J2208A)
    {
        NSNumber * numberHR = deviceData.dicData[@"heartRate"];
        strText  = [strText stringByAppendingFormat:@"\n heartRate:%@",numberHR];
    }
    else if (deviceData.dataType == DeviceMeasurement_Spo2_J2208A)
    {
        NSNumber * numberSpo2 = deviceData.dicData[@"spo2"];
        strText  = [strText stringByAppendingFormat:@"\n spo2:%@",numberSpo2];
    }
    else if (deviceData.dataType == DeviceMeasurement_HRV_J2208A)
    {
        NSNumber * numberSbp = deviceData.dicData[@"sbp"];
        NSNumber * numberHRV = deviceData.dicData[@"hrv"];
        NSNumber * numberDbp = deviceData.dicData[@"dbp"];

        strText  = [strText stringByAppendingFormat:@" hrv:%@\n BP:%@/%@\n\n",numberHRV,numberSbp,numberDbp];
    }
    else if (deviceData.dataType == DeviceMeasurement_Temperature_J2208A)
    {
        NSNumber * numberTemperature = deviceData.dicData[@"temperature"];
        strText  = [strText stringByAppendingFormat:@"\n temperature:%@",numberTemperature];
    }
  
    myTextView.text = strText;
    
    
    
}

- (IBAction)start:(UIButton *)sender {
    if([[NewBle sharedManager] isConnectOrConnecting]==YES){
        strText = @"";
        int dataType = (int)segDataType.selectedSegmentIndex;
        NSMutableData * data = [[BleSDK_J2208A sharedManager] StartDeviceMeasurementWithType:dataType+1 isOpen:YES];
        [[NewBle sharedManager] writeValue:SERVICE characteristicUUID:SEND_CHAR p:[NewBle sharedManager].activityPeripheral data:data];
    }
    else
        [PishumToast showToastWithMessage:LocalForkey(@"设备未连接") Length:TOAST_SHORT ParentView:self.view];
    
}
- (IBAction)back:(UIButton *)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

@end
