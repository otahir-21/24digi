//
//  AlarmClockDetailView.h
//  JC Health
//
//  Created by  on 2020/12/17.
//  Copyright © 2020 杨赛. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AlarmClockDetailView : UIViewController
@property int numberClock;
@end

NS_ASSUME_NONNULL_END
